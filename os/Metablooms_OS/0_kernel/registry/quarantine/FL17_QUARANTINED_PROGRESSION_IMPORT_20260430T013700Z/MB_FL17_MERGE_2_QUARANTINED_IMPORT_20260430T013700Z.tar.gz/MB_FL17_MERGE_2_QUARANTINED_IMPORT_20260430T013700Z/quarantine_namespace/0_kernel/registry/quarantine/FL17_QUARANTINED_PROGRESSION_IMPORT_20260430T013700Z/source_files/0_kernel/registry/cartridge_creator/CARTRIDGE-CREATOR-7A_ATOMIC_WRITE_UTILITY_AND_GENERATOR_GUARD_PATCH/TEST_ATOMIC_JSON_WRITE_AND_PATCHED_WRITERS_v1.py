#!/usr/bin/env python3
from __future__ import annotations
import json, os, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path('/mnt/data/Metablooms_OS')
SCRIPT_DIR=ROOT/'0_kernel/scripts'
sys.path.insert(0, str(SCRIPT_DIR))
from metablooms_atomic_json_v1 import write_json_atomic, load_json

def sha(path: Path)->str:
    import hashlib
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    out_dir=Path(sys.argv[1])
    out_dir.mkdir(parents=True, exist_ok=True)
    results=[]
    # Test 1: successful publish writes valid JSON and no temp remnants.
    target=out_dir/'atomic_target.json'
    expected={'before': True, 'n': 1}
    s=write_json_atomic(target, expected)
    results.append({'test':'successful_publish_valid_json','passed':load_json(target)==expected and len(s)==64})
    leftovers=list(out_dir.glob('.atomic_target.json.*.tmp'))
    results.append({'test':'no_temp_remnants_after_success','passed':len(leftovers)==0,'leftovers':[str(p) for p in leftovers]})
    # Test 2: simulated failure before replace preserves prior target.
    before_text=target.read_text(encoding='utf-8')
    before_sha=sha(target)
    failed=False
    try:
        write_json_atomic(target, {'after': False, 'should_not_publish': True}, simulate_failure_before_replace=True)
    except RuntimeError as exc:
        failed='simulated_failure_before_replace' in str(exc)
    after_sha=sha(target)
    results.append({'test':'simulated_failure_raised','passed':failed})
    results.append({'test':'target_preserved_on_failure','passed':before_sha==after_sha and target.read_text(encoding='utf-8')==before_text})
    results.append({'test':'no_direct_target_truncation_on_failure','passed':target.stat().st_size>0 and json.loads(target.read_text(encoding='utf-8'))==expected})
    leftovers=list(out_dir.glob('.atomic_target.json.*.tmp'))
    results.append({'test':'temp_cleanup_after_failure','passed':len(leftovers)==0,'leftovers':[str(p) for p in leftovers]})
    # Test 3: patched writer scripts compile and have no direct json.dumps write_text.
    patched=[
        SCRIPT_DIR/'cartridge_creator_capability_surface_executor_dry_run_v1.py',
        SCRIPT_DIR/'cartridge_creator_recursive_research_executor_dry_run_v1.py',
        SCRIPT_DIR/'cartridge_creator_see_ce_packet_generator_dry_run_v1.py',
        SCRIPT_DIR/'cartridge_creator_stage_runner_dry_run_v1.py',
        SCRIPT_DIR/'router_decision_producer_dry_run_v1.py',
    ]
    compile_cmd=[sys.executable,'-S','-m','py_compile',str(SCRIPT_DIR/'metablooms_atomic_json_v1.py')]+[str(p) for p in patched]
    cp=subprocess.run(compile_cmd,text=True,capture_output=True)
    results.append({'test':'patched_scripts_compile','passed':cp.returncode==0,'stderr':cp.stderr[-1000:]})
    direct=[]
    missing_import=[]
    for p in patched:
        txt=p.read_text(encoding='utf-8')
        if 'write_text(json.dumps' in txt:
            direct.append(str(p))
        if 'from metablooms_atomic_json_v1 import write_json_atomic as write_json' not in txt:
            missing_import.append(str(p))
    results.append({'test':'no_direct_json_write_text_in_patched_scripts','passed':not direct,'direct':direct})
    results.append({'test':'patched_scripts_use_atomic_writer_import','passed':not missing_import,'missing_import':missing_import})
    report={'artifact_type':'ATOMIC_JSON_WRITE_AND_PATCHED_WRITERS_TEST_REPORT','results':results,'passed':all(r.get('passed') for r in results)}
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report['passed'] else 1
if __name__=='__main__':
    raise SystemExit(main())
