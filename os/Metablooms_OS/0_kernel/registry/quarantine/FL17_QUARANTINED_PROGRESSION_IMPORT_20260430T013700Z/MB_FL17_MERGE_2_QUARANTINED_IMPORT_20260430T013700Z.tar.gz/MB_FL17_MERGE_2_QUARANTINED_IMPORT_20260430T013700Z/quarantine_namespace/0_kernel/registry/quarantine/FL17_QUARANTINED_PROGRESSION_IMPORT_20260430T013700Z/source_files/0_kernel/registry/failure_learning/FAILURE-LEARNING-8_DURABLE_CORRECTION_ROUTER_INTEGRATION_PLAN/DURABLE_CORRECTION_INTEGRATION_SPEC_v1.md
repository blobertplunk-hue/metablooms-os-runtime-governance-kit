# Durable Correction Router Integration Spec v1

Stage: `FAILURE-LEARNING-8_DURABLE_CORRECTION_ROUTER_INTEGRATION_PLAN`  
Created UTC: `20260429T212358Z`

## Purpose

Design production integration of the MetaBlooms Durable Correction Router into the boot/router preflight path without patching runtime gates in this stage. The goal is an OS immune-system loop: captured failures become classified problems, problems become durable correction work orders, work orders route to bounded repair workflows, repairs close only after regression proof, and all decisions remain artifact-auditable.

## Production integration sequence

1. **Default boot** loads baseline, tracker, failure-learning, and router state.
2. **Durable correction preflight** scans pending work-order state artifacts before ordinary routing.
3. If no blocking/trust-boundary work order exists, ordinary router proceeds.
4. If a blocking/trust-boundary repair exists, ordinary user-task lanes are denied and the router emits `REPAIR_FIRST_REQUIRED`.
5. Allowed lanes under repair-first: `BOOT`, `RECOVERY`, `AUDIT`, `GOVERNANCE_REPAIR`, and explicit user change-control approval.
6. If the router/gate/boot/tracker/failure-learning ledger is itself the blocking target, the preflight emits `EMERGENCY_RECOVERY_MODE` with console-safe fallback and later ledger reconciliation.

## Self-healing default boot state

Self-healing is not uncontrolled self-modification. It is a governed boot state that detects blocking durable-correction obligations and routes work into a repair-first workflow. Repairs still require bounded stage execution, evidence, regression fixtures, tracker finalization, failure-learning logs, and change-control classification.

## Repair lifecycle trace model

Trace spans are modeled as parent-child lifecycle spans:

- `Repair_Triage`
- `Change_Control_Decision`
- `Repair_Route_Selected`
- `Fix_Applied`
- `Regression_Verification`
- `Closure_Decision`
- `Ledger_Reconciliation`

Each span carries `trace_id`, `span_id`, `parent_span_id`, `stage_id`, `work_order_id`, `change_request_id`, `router_decision`, `severity`, `target_artifacts`, and `verdict`. Human reasoning belongs in separate reports; machine records stay JSON.

## Emergency recovery fail-safe

Emergency recovery is allowed only when the failing target is a core immune-system component: boot, governance gate, router, tracker, or failure-learning ledger. It must preserve ordinary-task denial, emit minimal console-safe reporting if the JSONL pipe is unavailable, and require reconciliation into normal ledgers once restored.

## Export finalization policy

This stage performs a user-requested clean-room ZIP export. Future always-on export must be gated by archive budget, timeout safety, size threshold, self-consistency validation, checksum sidecar generation, and the absence of blocking repair-first work orders. Until the central transactional runner exists, every-turn export is a policy design, not activated runtime behavior.

## Global atomic-write invariant

System-level writes must use same-directory temporary files, validated content, and `os.replace` where the tool path allows direct file control. Derived artifacts must verify no stray `.tmp` remains. External tools that do not expose this control must be wrapped or classified with a risk record.
